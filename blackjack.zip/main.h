#ifndef MAIN_H
#define MAIN_H

int szame(char *inp, int menue);
int input();

#endif