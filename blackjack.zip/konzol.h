#ifndef KONZOL_H
#define KONZOL_H

#include "jatek.h"
#include "jatekmenet.h"

void jatekosmenu();

void mainmenu();

void jatekmenu();

void asztalrajz(Jatek jatek);
void lapmenu(Asztalnal jatekos);
void botnev(Asztalnal jatekos);

void logo();

#endif