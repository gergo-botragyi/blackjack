#include <stdio.h>
#include "gyik.h"
#include "econio.h"
#include "debugmalloc.h"

//a gyik menuert felelos function
int gyik(){
    econio_clrscr();
    printf("gyik\n");
    return 0;
}