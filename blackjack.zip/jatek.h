#ifndef JATEK_H
#define JATEK_H

#include "jatekos.h"

Jatekostomb ujjatek(Jatekostomb jatekostomb);

void nevekkiir(Jatekostomb jatekosok);

void removetext(int kezdsor, int vegsor);
#endif