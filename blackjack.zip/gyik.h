#ifndef GYIK_H
#define GYIK_H

int gyik();

#endif